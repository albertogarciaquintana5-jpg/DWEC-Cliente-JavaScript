// Any y Object
// Any
var list = [1, '2', true];
var user = {
    name: "Tu nombre",
    age: 29,
    havePets: true
};
console.log("Primer elemento de la lista:", list[0]);
console.log("Usuario:", user);
