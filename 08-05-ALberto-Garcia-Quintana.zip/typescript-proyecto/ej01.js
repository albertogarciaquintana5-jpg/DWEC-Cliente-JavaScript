"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log("Hello world!");
//# sourceMappingURL=ej01.js.map