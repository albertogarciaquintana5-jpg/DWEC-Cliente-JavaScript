var miNombre = "Miguel";
var contador = 0;
for (contador = 0; contador < 10; contador++) {
    console.log(miNombre + contador);
}
