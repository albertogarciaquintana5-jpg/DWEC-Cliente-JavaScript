let miNombre: string = "Miguel";
let contador: number = 0;
for (contador = 0; contador < 10; contador++) {
    console.log(miNombre + contador);
}
